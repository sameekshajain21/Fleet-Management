import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

public class FleetHighwaySimulatorFrame extends JFrame {

    private final List<Vehicle> vehicles = new ArrayList<>();
    private final List<Thread> vehicleThreads = new ArrayList<>();

    private VehicleTableModel tableModel;
    private JTable vehicleTable;
    private JLabel highwayCounterLabel;
    private JCheckBox syncCheckBox; // unchecked: race condition, checked: synchronised

    private JButton startButton;
    private JButton pauseButton;
    private JButton resumeButton;
    private JButton stopButton;
    private JButton refuelButton;

    private javax.swing.Timer uiTimer;

    public FleetHighwaySimulatorFrame() {
        super("Fleet Highway Simulator");

        initVehicles();
        initComponents();
        layoutComponents();
        attachListeners();

        pack();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initVehicles() {
        // At least 3 vehicles (you can reuse your existing Vehicle model here)
        vehicles.add(new Vehicle("V1", 10));
        vehicles.add(new Vehicle("V2", 12));
        vehicles.add(new Vehicle("V3", 15));
    }

    private void initComponents() {
        tableModel = new VehicleTableModel(vehicles);
        vehicleTable = new JTable(tableModel);

        highwayCounterLabel = new JLabel("Highway Distance: 0 km");

        syncCheckBox = new JCheckBox("Use Synchronization (fix race condition)");
        syncCheckBox.setSelected(false); // start with race condition

        startButton = new JButton("Start");
        pauseButton = new JButton("Pause");
        resumeButton = new JButton("Resume");
        stopButton = new JButton("Stop");
        refuelButton = new JButton("Refuel Selected");

        pauseButton.setEnabled(false);
        resumeButton.setEnabled(false);
        stopButton.setEnabled(false);
        refuelButton.setEnabled(false);

        // Swing Timer to refresh UI from EDT
        uiTimer = new javax.swing.Timer(500, (ActionEvent e) -> refreshUI());
    }

    private void layoutComponents() {
        setLayout(new BorderLayout(10, 10));

        add(new JScrollPane(vehicleTable), BorderLayout.CENTER);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(highwayCounterLabel, BorderLayout.WEST);
        topPanel.add(syncCheckBox, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(startButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(resumeButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(refuelButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void attachListeners() {
        startButton.addActionListener(e -> startSimulation());
        pauseButton.addActionListener(e -> pauseSimulation());
        resumeButton.addActionListener(e -> resumeSimulation());
        stopButton.addActionListener(e -> stopSimulation());
        refuelButton.addActionListener(e -> refuelSelectedVehicle());

        syncCheckBox.addActionListener(e ->
                HighwayCounter.setUseSynchronization(syncCheckBox.isSelected()));
    }

    private void startSimulation() {
        // Reset the counter for a fresh run
        HighwayCounter.reset();
        HighwayCounter.setUseSynchronization(syncCheckBox.isSelected());

        if (vehicleThreads.isEmpty()) {
            for (Vehicle v : vehicles) {
                Thread t = new Thread(v, "Vehicle-" + v.getId());
                vehicleThreads.add(t);
                t.start();
            }
        }

        // Resume all vehicles
        for (Vehicle v : vehicles) {
            v.resume();
        }

        uiTimer.start();

        startButton.setEnabled(false);
        pauseButton.setEnabled(true);
        resumeButton.setEnabled(false);
        stopButton.setEnabled(true);
        refuelButton.setEnabled(true);
    }

    private void pauseSimulation() {
        for (Vehicle v : vehicles) {
            v.pause();
        }
        pauseButton.setEnabled(false);
        resumeButton.setEnabled(true);
    }

    private void resumeSimulation() {
        for (Vehicle v : vehicles) {
            v.resume();
        }
        pauseButton.setEnabled(true);
        resumeButton.setEnabled(false);
    }

    private void stopSimulation() {
        for (Vehicle v : vehicles) {
            v.stop();
        }
        for (Thread t : vehicleThreads) {
            t.interrupt();
        }
        vehicleThreads.clear();

        uiTimer.stop();

        startButton.setEnabled(true);
        pauseButton.setEnabled(false);
        resumeButton.setEnabled(false);
        stopButton.setEnabled(false);
        refuelButton.setEnabled(false);
    }

    private void refuelSelectedVehicle() {
        int row = vehicleTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    "Please select a vehicle row to refuel.",
                    "No Vehicle Selected",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Vehicle v = tableModel.getVehicleAt(row);

        String input = JOptionPane.showInputDialog(this,
                "Enter fuel amount to add for " + v.getId() + ":",
                "Refuel Vehicle",
                JOptionPane.PLAIN_MESSAGE);

        if (input == null) {
            return; // user cancelled
        }

        try {
            int amount = Integer.parseInt(input.trim());
            if (amount <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Fuel amount must be positive.",
                        "Invalid Input",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
            v.refuel(amount);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid integer for fuel.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Called periodically on the EDT by uiTimer
    private void refreshUI() {
        highwayCounterLabel.setText("Highway Distance: " + HighwayCounter.getDistance() + " km");
        tableModel.refresh();
    }
}
