import java.util.concurrent.locks.ReentrantLock;

public class HighwayCounter {
    private static int highwayDistance = 0;
    private static final ReentrantLock lock = new ReentrantLock();
    private static volatile boolean useSynchronization = false;

    // Toggle between race-condition version and synchronized version
    public static void setUseSynchronization(boolean useSync) {
        useSynchronization = useSync;
    }

    public static boolean isUsingSynchronization() {
        return useSynchronization;
    }

    // This is what all Vehicle threads call
    public static void increment() {
        if (useSynchronization) {
            incrementSynchronized();
        } else {
            incrementUnsafe();
        }
    }

    // Unsynchronised update – shows race condition with multiple threads
    private static void incrementUnsafe() {
        highwayDistance++; // no lock, no synchronized -> race condition
    }

    // Properly synchronised update – fixes race condition
    private static void incrementSynchronized() {
        lock.lock();
        try {
            highwayDistance++;
        } finally {
            lock.unlock();
        }
    }

    public static int getDistance() {
        return highwayDistance;
    }

    public static void reset() {
        highwayDistance = 0;
    }
}
