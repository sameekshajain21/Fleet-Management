public enum VehicleStatus {
    RUNNING,
    PAUSED,
    OUT_OF_FUEL,
    STOPPED
}
