import javax.swing.table.AbstractTableModel;
import java.util.List;

public class VehicleTableModel extends AbstractTableModel {
    private final List<Vehicle> vehicles;
    private final String[] columns = {"ID", "Mileage (km)", "Fuel", "Status"};

    public VehicleTableModel(List<Vehicle> vehicles) {
        this.vehicles = vehicles;
    }

    @Override
    public int getRowCount() {
        return vehicles.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Vehicle v = vehicles.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> v.getId();
            case 1 -> v.getMileage();
            case 2 -> v.getFuel();
            case 3 -> v.getStatus();
            default -> "";
        };
    }

    public Vehicle getVehicleAt(int row) {
        return vehicles.get(row);
    }

    public void refresh() {
        fireTableDataChanged();
    }
}
