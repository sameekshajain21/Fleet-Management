import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FleetHighwaySimulatorFrame frame = new FleetHighwaySimulatorFrame();
            frame.setVisible(true);
        });
    }
}
