public class Vehicle implements Runnable {
    private final String id;
    private volatile int mileage;
    private volatile int fuel;
    private volatile VehicleStatus status;

    private volatile boolean running = true;
    private volatile boolean paused = false;

    private final int fuelConsumptionPerKm; // how much fuel per km
    private final int sleepMillis;          // update interval

    public Vehicle(String id, int initialFuel) {
        this(id, initialFuel, 1, 1000);
    }

    public Vehicle(String id, int initialFuel, int fuelConsumptionPerKm, int sleepMillis) {
        this.id = id;
        this.fuel = initialFuel;
        this.mileage = 0;
        this.status = VehicleStatus.PAUSED; // will start in PAUSED until GUI starts it
        this.fuelConsumptionPerKm = fuelConsumptionPerKm;
        this.sleepMillis = sleepMillis;
    }

    @Override
    public void run() {
        while (running) {
            try {
                Thread.sleep(sleepMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }

            if (!running) {
                break;
            }

            if (paused) {
                // just loop without updating state
                continue;
            }

            if (fuel <= 0) {
                status = VehicleStatus.OUT_OF_FUEL;
                paused = true; // auto pause when out of fuel
                continue;
            }

            // Simulate 1 km travel
            mileage++;
            fuel -= fuelConsumptionPerKm;

            // Update shared highway distance counter (may be racey or synchronised)
            HighwayCounter.increment();

            status = VehicleStatus.RUNNING;
        }

        status = VehicleStatus.STOPPED;
    }

    // ----- Control methods -----

    public void pause() {
        paused = true;
        if (status == VehicleStatus.RUNNING) {
            status = VehicleStatus.PAUSED;
        }
    }

    public void resume() {
        if (fuel > 0) {
            paused = false;
            status = VehicleStatus.RUNNING;
        } else {
            status = VehicleStatus.OUT_OF_FUEL;
        }
    }

    public void stop() {
        running = false;
        paused = false;
    }

    public void refuel(int amount) {
        if (amount <= 0) return;
        fuel += amount;
        if (status == VehicleStatus.OUT_OF_FUEL) {
            // Automatically resume after refuel
            paused = false;
            status = VehicleStatus.RUNNING;
        }
    }

    // ----- Getters -----

    public String getId() {
        return id;
    }

    public int getMileage() {
        return mileage;
    }

    public int getFuel() {
        return fuel;
    }

    public VehicleStatus getStatus() {
        return status;
    }
}
